<?php

	
require 'class/class.phpmailer.php';

$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'mail.linnomgroup.co.za';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'noreply@linnomgroup.co.za';                 // SMTP username
$mail->Password = 'linnomgroup1';                           // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to

$mail->From = 'noreply@linnomgroup.co.za';
$mail->FromName = 'Linnom Group';
$mail->addAddress('linnomgroup@gmail.com');     // Add a recipient
$mail->addReplyTo('info@linnomgroup.co.za.co.za', 'Information');

$mail->WordWrap = 1500;                                 // Set word wrap to 50 characters
$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'Account Registration';
$mail->Body    = '<style>
      .email {
        max-width: 480px;
        margin: 1rem auto;
        border-radius: 10px;
        border-top: #d74034 2px solid;
        border-bottom: #d74034 2px solid;
        box-shadow: 0 2px 18px rgba(0, 0, 0, 0.2);
        padding: 1.5rem;
        font-family: Arial, Helvetica, sans-serif;
      }
      .email .email-head {
        border-bottom: 1px solid rgba(0, 0, 0, 0.2);
        padding-bottom: 1rem;
      }
      .email .email-head .head-img {
        max-width: 240px;
        padding: 0 0.5rem;
        display: block;
        margin: 0 auto;
      }

      .email .email-head .head-img img {
        width: 100%;
      }
      .email-body .invoice-icon {
        max-width: 80px;
        margin: 1rem auto;
      }
      .email-body .invoice-icon img {
        width: 100%;
      }

      .email-body .body-text {
        padding: 2rem 0 1rem;
        text-align: center;
        font-size: 1.15rem;
      }
      .email-body .body-text.bottom-text {
        padding: 2rem 0 1rem;
        text-align: center;
        font-size: 0.8rem;
      }
      .email-body .body-text .body-greeting {
        font-weight: bold;
        margin-bottom: 1rem;
      }

      .email-body .body-table {
        text-align: left;
      }
      .email-body .body-table table {
        width: 100%;
        font-size: 1.1rem;
      }
      .email-body .body-table table .total {
        background-color: hsla(4, 67%, 52%, 0.12);
        border-radius: 8px;
        color: #d74034;
      }
      .email-body .body-table table .item {
        border-radius: 8px;
        color: #d74034;
      }
      .email-body .body-table table th,
      .email-body .body-table table td {
        padding: 10px;
      }
      .email-body .body-table table tr:first-child th {
        border-bottom: 1px solid rgba(0, 0, 0, 0.2);
      }
      .email-body .body-table table tr td:last-child {
        text-align: right;
      }
      .email-body .body-table table tr th:last-child {
        text-align: right;
      }
      .email-body .body-table table tr:last-child th:first-child {
        border-radius: 8px 0 0 8px;
      }
      .email-body .body-table table tr:last-child th:last-child {
        border-radius: 0 8px 8px 0;
      }
      .email-footer {
        border-top: 1px solid rgba(0, 0, 0, 0.2);
      }
      .email-footer .footer-text {
        font-size: 0.8rem;
        text-align: center;
        padding-top: 1rem;
      }
      .email-footer .footer-text a {
        color: #d74034;
      }
    </style>
  </head>
  <body>
    <div class="email">
      <div class="email-head">
        <div class="head-img">
          <img
            src="https://linnomgroup.co.za/assets/img/logox.png"
            alt="damnitrahul-logo"
          />
        </div>
      </div>
      <div class="email-body">
        <div class="body-text">
          <div class="body-greeting">
            Hi, Rahul!
          </div>
          Your order has been successfully completed and delivered to You!
        </div>
        <div class="invoice-icon">
          <img src="https://cdn-icons-png.flaticon.com/512/4306/4306889.png" alt="invoice-icon" />
        </div>
        <div class="body-table">
          <table>
            <tr class="item">
              <th>Service Provided</th>
              <th>Qnty</th>
              <th>Amount</th>
            </tr>
            <tr>
              <td>Custom Graphic/Illustration</td>
              <td>2</td>
              <td>R1500</td>
            </tr>
            <tr>
              <td>Custom Graphic/Illustration</td>
              <td>3</td>
              <td>R1500</td>
            </tr>
            <tr>
              <td>Custom Graphic/Illustration</td>
              <td>3</td>
              <td>R1500</td>
            </tr>
            <tr class="total">
              <th>Total</th>
              <th></th>
              <td>R1500</td>
            </tr>
          </table>
        </div>
        <div class="body-text bottom-text">
          Thank You for giving me the opportunity to work on this project. I
          hope the product met your expectations. I look forward to working with
          You &#708;_&#708;
        </div>
      </div>
      <div class="email-footer">
        <div class="footer-text">
          &copy; <a href="https://damnitrahul.com/"  target="_blank">damnitrahul.com</a>
        </div>
      </div>
    </div>
  </body>';


if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
     echo "<script>
         setTimeout(function(){
            window.location.href = '../thank.html';
         }, 0);
      </script>" ;
}