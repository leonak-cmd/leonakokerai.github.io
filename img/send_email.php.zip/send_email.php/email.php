<?php
session_start();

if ( $_SESSION['logged_in'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: ../login.php");    
}
else {
    // Makes it easier to read
   
     $email = $_SESSION['email'];
     $name = $_SESSION['name'];
     $phone = $_SESSION['phone'];
     $userid = $_SESSION['user_id'];
}
?>
<?php

	
require 'class/class.phpmailer.php';

$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'mail.linnomgroup.co.za';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'noreply@linnomgroup.co.za';                 // SMTP username
$mail->Password = 'linnomgroup1';                           // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to

$mail->From = 'noreply@linnomgroup.co.za';
$mail->FromName = 'Linnom Group';
$mail->addAddress(''.$email.'',''.$name.'');     // Add a recipient
$mail->addReplyTo('info@linnomgroup.co.za.co.za', 'Information');

$mail->WordWrap = 1500;                                 // Set word wrap to 50 characters
$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'Account Registration';
$mail->Body    = '<!doctype html>
<html lang="en-US">

<head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <style type="text/css">
        a:hover {text-decoration: underline !important;}
    </style>
</head>

<body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0">
 
    <table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"
        style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: "Open Sans", sans-serif;">
        <tr>
            <td>
                <table style="background-color: #f2f3f8; max-width:670px;  margin:0 auto;" width="100%" border="0"
                    align="center" cellpadding="0" cellspacing="0">
                    <tr>
                        <td style="height:80px;">&nbsp;</td>
                    </tr>
                    <tr>
                        <td style="text-align:center;">
                          <a href="https://oyannahgroup.co.za" title="logo" target="_blank">
                            <img width="190" src="https://oyannahgroup.co.za/old/images/OYANNAH2.png" title="logo" alt="logo">
                          </a>
                        </td>
                    </tr>
                    <tr>
                        <td style="height:20px;">&nbsp;</td>
                    </tr>
                    <tr>
                        <td>
                            <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0"
                                style="max-width:670px;background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);">
                                <tr>
                                    <td style="height:40px;">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="padding:0 35px;">
                                        
                                        <p align="left" style="color:#455056; line-height:24px; margin:0;">
Hello '.$name.' <br>                                           
Thanks for your interest in our software.<br>

<br>

Reference no: '.$user_id.'<br>
Deposit: R 350<br>
Grand Total: R 950<br><br>

Please use <b>'.$user_id.'</b> as your reference when making payments<br>
Pay the deposit to secure your seat<br><br>
<b>*Banking Details*</b><br>

Bank Name: Nedbank<br>
Payee Name: Oyannah<br>
Account Number: 1216277389<br>
Account type: Business PAYU<br>
Branch Code: 19840500<br><br>

Please send the proof of payment to our Email: billing@oyannahgroup.co.za<br><br>

Linnom Group Team<br>
Thank you<br>
                                        </p>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td style="height:40px;">&nbsp;</td>
                                </tr>
                            </table>
                        </td>
                    <tr>
                        <td style="height:20px;">&nbsp;</td>
                    </tr>
                    <tr>
                        <td style="text-align:center;">
                            <p style="font-size:14px; color:rgba(69, 80, 86, 0.7411764705882353); line-height:18px; margin:0 0 0;">&copy; <strong>www.oyannahgroup.co.za</strong></p>
                        </td>
                    </tr>
                    <tr>
                        <td style="height:80px;">&nbsp;</td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>

</body>

</html>';


if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
     echo "<script>
         setTimeout(function(){
            window.location.href = '../thank.html';
         }, 0);
      </script>" ;
}